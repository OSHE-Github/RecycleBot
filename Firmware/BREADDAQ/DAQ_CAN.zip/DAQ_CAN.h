#ifndef DAQ_CAN
#define DAQ_CAN

//Setup for CAN communication
#define CAN_SPI_CS 10
#define CAN_INT 2

//Storage for ID
unsigned int localID = BREAD_DAQ;
unsigned int dupID = 0;

MCP_CAN CAN(CAN_SPI_CS);

void initializeCAN();
void checkCAN();
void sendCANData(float data,uint32_t channel);
void changeID();

#endif